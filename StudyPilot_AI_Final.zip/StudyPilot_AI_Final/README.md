# StudyPilot AI

A student learning-support MVP built with Streamlit, Pandas, and SQLite.

## Features
- Dashboard with quiz and study-time summaries
- Subject pages, topic checklists, and official learning links
- 10-question Python quiz with score and explanations
- Built-in FAQ-style learning mentor (not a live generative AI integration)
- Progress charts and quiz history
- Study planner with locally saved sessions
- Student profile saved in SQLite

## Run on Windows
1. Extract the ZIP.
2. Open Command Prompt in the `StudyPilot_AI_Final` folder.
3. Run `python -m venv venv`
4. Run `venv\\Scripts\\activate`
5. Run `python -m pip install -r requirements.txt`
6. Run `python -m streamlit run app.py`
7. Open the Local URL shown in CMD, usually http://localhost:8501.

Python 3.10+ recommended.

## Notes
- Profile, quiz attempts, and study sessions are stored in `studypilot.db` on the computer running the app.
- The AI Mentor is a small rule-based FAQ helper. It does not call an external AI model.
- Topic checkboxes are session-only.
- This is an educational MVP, not a production service.

## GitHub
Do not commit secrets, private API keys, personal student data, virtual environments, or `studypilot.db`.
